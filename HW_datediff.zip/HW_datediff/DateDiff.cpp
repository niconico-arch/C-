#include <iostream>

using namespace std;

//function to count number of days before the input date 
int count_days(int date) {
	int year, month, day;
	int yearday, monthday;
	int totalDay;

	//number of year, month and day before the input date
	year = date / 10000 - 1;
	month = date / 100 - (date / 10000) * 100 - 1;
	day = date - (date / 100) * 100;

	//count number of days for given year considering leap year cases
	yearday = year * 365 + (year / 4 - year / 100 + year / 400);
	//count number of days for given month for different cases
	//the base of days is calculated by number of months multiply by 30 days and further adjusted by each month
	monthday = 30 * month;
	if (month == 2) {
		monthday -= 1;
	}
	else if (month == 5 || month == 6) {
		monthday += 1;
	}
	else if (month == 7) {
		monthday += 2;
	}
	else if (month == 8 || month == 9) {
		monthday += 3;
	}
	else if (month == 10 || month == 11) {
		monthday += 4;
	}
	else if (month == 12) {
		monthday += 5;
	}
	//set year to be current year for leap year calculation
	year = year + 1;
	//further adjust number of days for given month considering leap year case
	if (month > 2 && ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))) {
		monthday += 1;
	}
	//count total number of days by adding up days from year, month and day
	totalDay = yearday + monthday + day;
	return totalDay;
}

int main() {
	int		date1, date2, dateDiff;
	char	YN = 'y';

	cout << "Calculate the number of days between 2 dates" << endl;

	while (YN == 'y') {

		cout << endl << "Enter the first date (format: yyyymmdd):";
		cin >> date1;
		cout << "Enter the secound date (format: yyyymmdd):";
		cin >> date2;

		// Fill in the code to calculate the number of days between date1 and date2;
		// You may assume that date1 and date2 are valid dates.
		
		//calculate the difference of daycount for date1 and date2
		dateDiff = count_days(date2) - count_days(date1);

		cout << endl << "The number of days between " << date1 << " and " << date2 << " is " << dateDiff << endl;

		cout << endl << "Next calculation? (y/n): ";
		cin >> YN;

	}
	return 0;
}